import fp from 'fastify-plugin';
import { FastifyInstance, FastifyPluginAsync } from 'fastify';
import { correlationIdMiddleware, requestLoggerMiddleware, errorHandler } from '@rmn-erp/core';

const corePlugin: FastifyPluginAsync = async (fastify: FastifyInstance) => {
  // Register decorators or hooks from @rmn-erp/core
  if (correlationIdMiddleware) {
    fastify.addHook('onRequest', correlationIdMiddleware as any);
  }
  if (requestLoggerMiddleware) {
    fastify.addHook('onRequest', requestLoggerMiddleware as any);
  }
  if (errorHandler) {
    fastify.setErrorHandler(errorHandler as any);
  }
};

export default fp(corePlugin, { name: 'core-plugin' });
